package ch08;

import javax.swing.JFrame;

public class C extends JFrame {
	

}
