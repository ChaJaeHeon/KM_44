package ch02;    //패키지(유사한 기능을 가지는 클래스간의 묶음)라는 키워드를 선언할 때 사용

public class Variable1{

	public static void main(String[] args) {        //main method: 주요 함수, 형식이 정해져 있음
		int level;   //정수형 변수 level을 선언 , 선언은 했지만 초기화 되지 않은 선언
		level = 10;  //level 변수에 값 10을 대입, 초기화
		System.out.println(level);  //level값 출력
	}//end of main

}//end of class