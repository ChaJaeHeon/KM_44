package exception;

public class ExTest2 {

	public static void main(String[] args) {
	}

}
