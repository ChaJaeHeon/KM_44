package api;

public class IntegerTest2 {
	
		public static void main(String[] args) {
			
		}

}


//입력할 진법(2/8/10/16) : 2
//정수입력(2진수) : 111111
//변환할 진법(2/8/10/16): 16
//255(2) -> FF(16)