package api;

public class SchoolData {

}
