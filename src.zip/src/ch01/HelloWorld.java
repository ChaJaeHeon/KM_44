package ch01;

public class HelloWorld {

	/** document 주석 : api document 주석*/
	public static void main(String[] args) {
		/* 여러 줄 주석 */
		System.out.println("Hello World");
		System.out.println("Java Programming");
		
	}

}
