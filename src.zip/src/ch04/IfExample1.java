package ch04;

public class IfExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age = 7;
		if(age>=8) {
			System.out.println("학교에 다닙니다.");
		}
		else {
			System.out.println("학교에 다니지 않습니다.");
		}
	}

}
