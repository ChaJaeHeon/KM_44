package ch04.test;

public class Exam_15 {

	public static void main(String[] args) {
		
		for(int i=0;i<=4;i++) {
			System.out.println();
			for(int j=0; j<=4; j++) {
				System.out.print(j+" ");
			}
		}
		System.out.println();
		for(int i=0; i<=4; i++) {
			
		}
	}
}

